﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthie
{
    public class AttackRelease
    {
        private AudioNode source;
        private double attack;
        private double release;

        public AudioNode Source { get => source; set => source = value; }

        public double Attack { get => attack; set => attack = value; }

        public double Release { get => release; set => release = value; }

        public AttackRelease()
        {
            attack = 0.05;
            release = 0.05;
        }

        public double Envolope(double frame, double time, double duration)
        {
            if( time < attack || time > (duration - release))
            {
                return frame * Math.Min(time / attack, (duration - time) / release);
            }

            return frame;
        }
    }
}
