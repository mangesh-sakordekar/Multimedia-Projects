﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthie
{
    public class ToneInstrument : Instrument
    {
        private double duration;
        private SineWave sinewave = new SineWave();
        private double time;
        private AttackRelease ar = new AttackRelease();
        public double Frequency { get => sinewave.Frequency; set => sinewave.Frequency = value; }

        public ToneInstrument()
        {
            duration = 0.1;
        }

        public override bool Generate()
        {
            // Tell the component to generate an audio sample
            sinewave.Generate();

            // Read the component's sample and make it our resulting frame.
            //frame[0] = sinewave.Frame(0);
            //frame[1] = sinewave.Frame(1);
            frame[0] = ar.Envolope(sinewave.Frame(0), time, duration);
            frame[1] = ar.Envolope(sinewave.Frame(1), time, duration);

            // Update time
            time += samplePeriod;

            // We return true until the time reaches the duration.
            return time < duration;
        }

        public override void Start()
        {
            sinewave.SampleRate = SampleRate;
            sinewave.Start();
            time = 0;
        }

        public override void SetNote(Note note)
        {
            duration = note.Count * (60.0/bpm);
            Frequency = Notes.NoteToFrequency(note.Pitch);
        }
    }
}
