﻿namespace ImageProcess
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.openTestMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.openMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.closeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.generateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fillWhiteMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.negativeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.drawMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.processMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.copyMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.thresholdMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.warpNearestMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.warpBilenearMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.fillGreenOption = new System.Windows.Forms.ToolStripMenuItem();
            this.dimOption = new System.Windows.Forms.ToolStripMenuItem();
            this.tintOption = new System.Windows.Forms.ToolStripMenuItem();
            this.lowpassFilterOption = new System.Windows.Forms.ToolStripMenuItem();
            this.tasksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fillLightSteelBlueOption = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontalGradientOption = new System.Windows.Forms.ToolStripMenuItem();
            this.verticalBlueGradientOption = new System.Windows.Forms.ToolStripMenuItem();
            this.diagonalGradientOption = new System.Windows.Forms.ToolStripMenuItem();
            this.cornerDiagonalGradientOption = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontalLineOption = new System.Windows.Forms.ToolStripMenuItem();
            this.verticalLineOption = new System.Windows.Forms.ToolStripMenuItem();
            this.diagonalLineOption = new System.Windows.Forms.ToolStripMenuItem();
            this.monochromeOption = new System.Windows.Forms.ToolStripMenuItem();
            this.medianOption = new System.Windows.Forms.ToolStripMenuItem();
            this.makeSquareOption = new System.Windows.Forms.ToolStripMenuItem();
            this.makeArrowOption = new System.Windows.Forms.ToolStripMenuItem();
            this.makeAffineOption = new System.Windows.Forms.ToolStripMenuItem();
            this.skewOption = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.generateToolStripMenuItem,
            this.processMenu,
            this.tasksToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newMenu,
            this.openTestMenu,
            this.openMenu,
            this.saveMenu,
            this.closeMenu,
            this.exitMenu});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newMenu
            // 
            this.newMenu.Name = "newMenu";
            this.newMenu.Size = new System.Drawing.Size(126, 22);
            this.newMenu.Text = "&New";
            this.newMenu.Click += new System.EventHandler(this.newMenu_Click);
            // 
            // openTestMenu
            // 
            this.openTestMenu.Name = "openTestMenu";
            this.openTestMenu.Size = new System.Drawing.Size(126, 22);
            this.openTestMenu.Text = "Open &Test";
            this.openTestMenu.Click += new System.EventHandler(this.openTestMenu_Click);
            // 
            // openMenu
            // 
            this.openMenu.Name = "openMenu";
            this.openMenu.Size = new System.Drawing.Size(126, 22);
            this.openMenu.Text = "&Open";
            this.openMenu.Click += new System.EventHandler(this.openMenu_Click);
            // 
            // saveMenu
            // 
            this.saveMenu.Name = "saveMenu";
            this.saveMenu.Size = new System.Drawing.Size(126, 22);
            this.saveMenu.Text = "&Save";
            this.saveMenu.Click += new System.EventHandler(this.saveMenu_Click);
            // 
            // closeMenu
            // 
            this.closeMenu.Name = "closeMenu";
            this.closeMenu.Size = new System.Drawing.Size(126, 22);
            this.closeMenu.Text = "&Close";
            this.closeMenu.Click += new System.EventHandler(this.closeMenu_Click);
            // 
            // exitMenu
            // 
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(126, 22);
            this.exitMenu.Text = "&Exit";
            this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
            // 
            // generateToolStripMenuItem
            // 
            this.generateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillWhiteMenu,
            this.negativeMenu,
            this.toolStripSeparator1,
            this.drawMenu,
            this.fillGreenOption,
            this.dimOption,
            this.tintOption});
            this.generateToolStripMenuItem.Name = "generateToolStripMenuItem";
            this.generateToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.generateToolStripMenuItem.Text = "&Process";
            // 
            // fillWhiteMenu
            // 
            this.fillWhiteMenu.Name = "fillWhiteMenu";
            this.fillWhiteMenu.Size = new System.Drawing.Size(180, 22);
            this.fillWhiteMenu.Text = "&Fill White";
            this.fillWhiteMenu.Click += new System.EventHandler(this.fillWhiteMenu_Click);
            // 
            // negativeMenu
            // 
            this.negativeMenu.Name = "negativeMenu";
            this.negativeMenu.Size = new System.Drawing.Size(180, 22);
            this.negativeMenu.Text = "&Negative";
            this.negativeMenu.Click += new System.EventHandler(this.negativeMenu_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // drawMenu
            // 
            this.drawMenu.Name = "drawMenu";
            this.drawMenu.Size = new System.Drawing.Size(180, 22);
            this.drawMenu.Text = "&Draw";
            this.drawMenu.Click += new System.EventHandler(this.drawMenu_Click);
            // 
            // processMenu
            // 
            this.processMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyMenu,
            this.toolStripSeparator2,
            this.thresholdMenu,
            this.warpNearestMenu,
            this.warpBilenearMenu,
            this.lowpassFilterOption,
            this.makeSquareOption,
            this.makeArrowOption,
            this.makeAffineOption,
            this.skewOption});
            this.processMenu.Name = "processMenu";
            this.processMenu.Size = new System.Drawing.Size(66, 20);
            this.processMenu.Text = "&Generate";
            // 
            // copyMenu
            // 
            this.copyMenu.Name = "copyMenu";
            this.copyMenu.Size = new System.Drawing.Size(180, 22);
            this.copyMenu.Text = "&Copy";
            this.copyMenu.Click += new System.EventHandler(this.copyMenu_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(177, 6);
            // 
            // thresholdMenu
            // 
            this.thresholdMenu.Name = "thresholdMenu";
            this.thresholdMenu.Size = new System.Drawing.Size(180, 22);
            this.thresholdMenu.Text = "&Threshold";
            this.thresholdMenu.Click += new System.EventHandler(this.thresholdMenu_Click);
            // 
            // warpNearestMenu
            // 
            this.warpNearestMenu.Name = "warpNearestMenu";
            this.warpNearestMenu.Size = new System.Drawing.Size(180, 22);
            this.warpNearestMenu.Text = "&Warp Nearest";
            this.warpNearestMenu.Click += new System.EventHandler(this.warpNearestMenu_Click);
            // 
            // warpBilenearMenu
            // 
            this.warpBilenearMenu.Name = "warpBilenearMenu";
            this.warpBilenearMenu.Size = new System.Drawing.Size(180, 22);
            this.warpBilenearMenu.Text = "Warp &Bilenear";
            this.warpBilenearMenu.Click += new System.EventHandler(this.warpBilenearMenu_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "JPEG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|PNG Files (*.png)|*.png|BMP File" +
    "s (*.bmp)|*p.bmp|All files (*.*)|*.*";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "JPEG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|PNG Files (*.png)|*.png|BMP File" +
    "s (*.bmp)|*.bmp";
            // 
            // fillGreenOption
            // 
            this.fillGreenOption.Name = "fillGreenOption";
            this.fillGreenOption.Size = new System.Drawing.Size(180, 22);
            this.fillGreenOption.Text = "Fill Green";
            this.fillGreenOption.Click += new System.EventHandler(this.fillGreenOption_Click);
            // 
            // dimOption
            // 
            this.dimOption.Name = "dimOption";
            this.dimOption.Size = new System.Drawing.Size(180, 22);
            this.dimOption.Text = "Dim";
            this.dimOption.Click += new System.EventHandler(this.dimOption_Click);
            // 
            // tintOption
            // 
            this.tintOption.Name = "tintOption";
            this.tintOption.Size = new System.Drawing.Size(180, 22);
            this.tintOption.Text = "Tint";
            this.tintOption.Click += new System.EventHandler(this.tintOption_Click);
            // 
            // lowpassFilterOption
            // 
            this.lowpassFilterOption.Name = "lowpassFilterOption";
            this.lowpassFilterOption.Size = new System.Drawing.Size(180, 22);
            this.lowpassFilterOption.Text = "Lowpass Filter";
            this.lowpassFilterOption.Click += new System.EventHandler(this.lowpassFilterOption_Click);
            // 
            // tasksToolStripMenuItem
            // 
            this.tasksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillLightSteelBlueOption,
            this.horizontalGradientOption,
            this.verticalBlueGradientOption,
            this.diagonalGradientOption,
            this.cornerDiagonalGradientOption,
            this.horizontalLineOption,
            this.verticalLineOption,
            this.diagonalLineOption,
            this.monochromeOption,
            this.medianOption});
            this.tasksToolStripMenuItem.Name = "tasksToolStripMenuItem";
            this.tasksToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.tasksToolStripMenuItem.Text = "Tasks";
            // 
            // fillLightSteelBlueOption
            // 
            this.fillLightSteelBlueOption.Name = "fillLightSteelBlueOption";
            this.fillLightSteelBlueOption.Size = new System.Drawing.Size(208, 22);
            this.fillLightSteelBlueOption.Text = "Fill Light Steel Blue";
            this.fillLightSteelBlueOption.Click += new System.EventHandler(this.fillLightSteelBlueOption_Click);
            // 
            // horizontalGradientOption
            // 
            this.horizontalGradientOption.Name = "horizontalGradientOption";
            this.horizontalGradientOption.Size = new System.Drawing.Size(208, 22);
            this.horizontalGradientOption.Text = "Horizontal Gradient";
            this.horizontalGradientOption.Click += new System.EventHandler(this.horizontalGradientOption_Click);
            // 
            // verticalBlueGradientOption
            // 
            this.verticalBlueGradientOption.Name = "verticalBlueGradientOption";
            this.verticalBlueGradientOption.Size = new System.Drawing.Size(208, 22);
            this.verticalBlueGradientOption.Text = "Vertical Blue Gradient";
            this.verticalBlueGradientOption.Click += new System.EventHandler(this.verticalBlueGradientOption_Click);
            // 
            // diagonalGradientOption
            // 
            this.diagonalGradientOption.Name = "diagonalGradientOption";
            this.diagonalGradientOption.Size = new System.Drawing.Size(208, 22);
            this.diagonalGradientOption.Text = "Diagonal Gradient";
            this.diagonalGradientOption.Click += new System.EventHandler(this.diagonalGradientOption_Click);
            // 
            // cornerDiagonalGradientOption
            // 
            this.cornerDiagonalGradientOption.Name = "cornerDiagonalGradientOption";
            this.cornerDiagonalGradientOption.Size = new System.Drawing.Size(208, 22);
            this.cornerDiagonalGradientOption.Text = "Corner Diagonal Gradient";
            this.cornerDiagonalGradientOption.Click += new System.EventHandler(this.cornerDiagonalGradientOption_Click);
            // 
            // horizontalLineOption
            // 
            this.horizontalLineOption.Name = "horizontalLineOption";
            this.horizontalLineOption.Size = new System.Drawing.Size(208, 22);
            this.horizontalLineOption.Text = "Horizontal Line";
            this.horizontalLineOption.Click += new System.EventHandler(this.horizontalLineOption_Click);
            // 
            // verticalLineOption
            // 
            this.verticalLineOption.Name = "verticalLineOption";
            this.verticalLineOption.Size = new System.Drawing.Size(208, 22);
            this.verticalLineOption.Text = "Vertical Line";
            this.verticalLineOption.Click += new System.EventHandler(this.verticalLineOption_Click);
            // 
            // diagonalLineOption
            // 
            this.diagonalLineOption.Name = "diagonalLineOption";
            this.diagonalLineOption.Size = new System.Drawing.Size(208, 22);
            this.diagonalLineOption.Text = "Diagonal Line";
            this.diagonalLineOption.Click += new System.EventHandler(this.diagonalLineOption_Click);
            // 
            // monochromeOption
            // 
            this.monochromeOption.Name = "monochromeOption";
            this.monochromeOption.Size = new System.Drawing.Size(208, 22);
            this.monochromeOption.Text = "Monochrome";
            this.monochromeOption.Click += new System.EventHandler(this.monochromeOption_Click);
            // 
            // medianOption
            // 
            this.medianOption.Name = "medianOption";
            this.medianOption.Size = new System.Drawing.Size(208, 22);
            this.medianOption.Text = "Median";
            this.medianOption.Click += new System.EventHandler(this.medianOption_Click);
            // 
            // makeSquareOption
            // 
            this.makeSquareOption.Name = "makeSquareOption";
            this.makeSquareOption.Size = new System.Drawing.Size(180, 22);
            this.makeSquareOption.Text = "Make Square";
            this.makeSquareOption.Click += new System.EventHandler(this.makeSquareOption_Click);
            // 
            // makeArrowOption
            // 
            this.makeArrowOption.Name = "makeArrowOption";
            this.makeArrowOption.Size = new System.Drawing.Size(180, 22);
            this.makeArrowOption.Text = "Make Arrow";
            this.makeArrowOption.Click += new System.EventHandler(this.makeArrowOption_Click);
            // 
            // makeAffineOption
            // 
            this.makeAffineOption.Name = "makeAffineOption";
            this.makeAffineOption.Size = new System.Drawing.Size(180, 22);
            this.makeAffineOption.Text = "Make Affine";
            this.makeAffineOption.Click += new System.EventHandler(this.makeAffineOption_Click);
            // 
            // skewOption
            // 
            this.skewOption.Name = "skewOption";
            this.skewOption.Size = new System.Drawing.Size(180, 22);
            this.skewOption.Text = "Skew";
            this.skewOption.Click += new System.EventHandler(this.skewOption_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Image Process: Sakordekar Mangesh";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newMenu;
        private System.Windows.Forms.ToolStripMenuItem openTestMenu;
        private System.Windows.Forms.ToolStripMenuItem openMenu;
        private System.Windows.Forms.ToolStripMenuItem saveMenu;
        private System.Windows.Forms.ToolStripMenuItem closeMenu;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.ToolStripMenuItem generateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fillWhiteMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem processMenu;
        private System.Windows.Forms.ToolStripMenuItem thresholdMenu;
        private System.Windows.Forms.ToolStripMenuItem warpNearestMenu;
        private System.Windows.Forms.ToolStripMenuItem warpBilenearMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ToolStripMenuItem copyMenu;
        private System.Windows.Forms.ToolStripMenuItem negativeMenu;
        private System.Windows.Forms.ToolStripMenuItem drawMenu;
        private System.Windows.Forms.ToolStripMenuItem fillGreenOption;
        private System.Windows.Forms.ToolStripMenuItem dimOption;
        private System.Windows.Forms.ToolStripMenuItem tintOption;
        private System.Windows.Forms.ToolStripMenuItem lowpassFilterOption;
        private System.Windows.Forms.ToolStripMenuItem tasksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fillLightSteelBlueOption;
        private System.Windows.Forms.ToolStripMenuItem horizontalGradientOption;
        private System.Windows.Forms.ToolStripMenuItem verticalBlueGradientOption;
        private System.Windows.Forms.ToolStripMenuItem diagonalGradientOption;
        private System.Windows.Forms.ToolStripMenuItem cornerDiagonalGradientOption;
        private System.Windows.Forms.ToolStripMenuItem horizontalLineOption;
        private System.Windows.Forms.ToolStripMenuItem verticalLineOption;
        private System.Windows.Forms.ToolStripMenuItem diagonalLineOption;
        private System.Windows.Forms.ToolStripMenuItem monochromeOption;
        private System.Windows.Forms.ToolStripMenuItem medianOption;
        private System.Windows.Forms.ToolStripMenuItem makeSquareOption;
        private System.Windows.Forms.ToolStripMenuItem makeArrowOption;
        private System.Windows.Forms.ToolStripMenuItem makeAffineOption;
        private System.Windows.Forms.ToolStripMenuItem skewOption;
    }
}

