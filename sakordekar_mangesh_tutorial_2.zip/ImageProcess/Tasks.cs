﻿/**
 * *************** File Header ****************************
 * 
 * File Name : MainForm.cs
 * 
 * Class: CSC 524 Digital Image Processing
 * 
 * Project: Tutorial 2
 * 
 * Author: Mangesh Sakordekar
 * 
 * Description:
 * This file contains code to handle tasks.
 * 
 * Bugs/Errors: None
 * 
 * 
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static System.Net.Mime.MediaTypeNames;
using Point = System.Windows.Point;

namespace ImageProcess
{
    internal class Tasks
    {
        #region General Tasks

        /// <summary>
        /// This class function fills the base image with light steel blue.
        /// </summary>
        /// <param name="image"></param>
        public static void FillLightSteelBlue(RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            for (int r = 0; r < height; r++)
            {
                // Looping over the columns of the array
                for (int c = 0; c < width; c++)
                {
                    image[c, r] = Color.LightSteelBlue;
                }
            }
        }

        /// <summary>
        /// This class function generates horizontal gradient image.
        /// </summary>
        /// <param name="image"></param>
        public static void HorizontalGradient(RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            for (int r = 0; r < height; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    image[c, r] = ColorHelpers.ColorMultiply((double)c / (double)width, Color.White);
                }
            }
        }

        /// <summary>
        /// This class function generates vertical gradient image.
        /// </summary>
        /// <param name="image"></param>
        public static void VerticalGradient(RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            for (int r = 0; r < height; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    image[c, r] = ColorHelpers.ColorMultiply((double)(height-r) / (double)height, Color.FromArgb(0,0,255));
                }
            }
        }

        /// <summary>
        /// This class function generates diagonal gradient image.
        /// </summary>
        /// <param name="image"></param>
        public static void DiagonalGradient(RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;
            int width_height = height * width;
            double delta = height / width;
            for (int r = 0; r < height; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    #region Other methods
                    /*
                    image[c, r] = ColorHelpers.ColorMultiply((double)(width_height - r * width + c * height) /(width_height), Color.Green);
                    image[c, r] = ColorHelpers.ColorAdd(
                        ColorHelpers.ColorMultiply((double)(width_height + r * width - c * height) /(width_height), Color.Red), 
                        image[c, r]);*/

                    /*
                    image[c, r] = ColorHelpers.ColorAdd(
                        ColorHelpers.ColorMultiply((double)((c*delta) + height - r) / (double)(height*2), Color.FromArgb(0,255,0)),
                        ColorHelpers.ColorMultiply((double)((width- c)*delta + r) / (double)(height*2), Color.FromArgb(225,0,0)));*/
                    #endregion

                    image[c, r] = ColorHelpers.ColorAdd(
                        ColorHelpers.ColorMultiply((double)(c + height - r) / (double)(height + width), Color.FromArgb(0,255,0)),
                        ColorHelpers.ColorMultiply((double)(width - c + r) / (double)(height + width), Color.FromArgb(225,0,0)));

                }
            }
        }

        /// <summary>
        /// This class function adds two horizontal lines to the base image .
        /// </summary>
        /// <param name="image"></param>
        public static void HorizontalLines(RasterImage image)
        {
            int width = image.Width;
            int height = image.Height;
            // Looping over the columns of the array
            for(int i = 100; i < height && i <= 200; i+=100 )
            {
                for (int c = 0; c < width; c++)
                {
                    image[c, i] = Color.Yellow;
                }
            }
        }

        /// <summary>
        /// This class function adds two vertical lines to the base image .
        /// </summary>
        /// <param name="image"></param>
        public static void VerticalLines(RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;
            List<int> cols = new List<int> { 100, 101, 400, 401 };

            // Looping over the columns of the array
            foreach (int col in cols)
            {
                if (col >= width)
                    continue;

                for (int r = 0; r < height; r++)
                {
                    image[col, r] = Color.Yellow;

                }
            }
        }

        /// <summary>
        /// This class function adds a diagonal line to the base image .
        /// </summary>
        /// <param name="image"></param>
        public static void DiagonalLines(RasterImage image)
        {
            
            int width = image.Width;
            int height = image.Height;
            // Looping over the columns of the array
            for (float c = 100, r = 100; r < height && c < width && r <= 400; c += (float)(1.0/3.0), r+=1)
            {
                image[(int)c, (int)r] = Color.Yellow;

                //Anti aliasing 
                int factor = 1;
                for(int i = -factor; i <= factor && i+r < height; i++)
                {
                    for(int j = -factor; j <= factor && j + c < width; j++)
                    {
                        image[(int)c+j, (int)r+i] = ColorHelpers.ColorAdd(
                            image[(int)c + j, (int)r + i], 
                            ColorHelpers.ColorMultiply(((2.0 * factor) + 0.75 - Math.Abs(j) - Math.Abs(j)) / (2.0 * factor) , Color.Yellow));
                    }
                }
            }
        }

        /// <summary>
        /// This class function changes the base image  to a monochrome image.
        /// </summary>
        /// <param name="image"></param>
        public static void Monochrome(RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            for (int r = 0; r < height; r++)
            {
                // Looping over the columns of the array
                for (int c = 0; c < width; c++)
                {
                    int temp = (image[c, r].R + image[c, r].G + image[c, r].B)/3;
                    image[c, r] = Color.FromArgb(temp, temp, temp);
                }
            }
        }

        public static void MedianFilter(RasterImage base_img, RasterImage post_img)
        {
            base_img.parallelFilter(post_img, ParallelMedianFilter);

            #region Not using parallel
            /*
            int height = base_img.Height;
            int width = base_img.Width;

            for (int r = 0; r < height; r++)
            {
                // Looping over the columns of the array
                for (int c = 0; c < width; c++)
                {
                    var temp = new List<Color>();
                    int factor = 1;
                    for(int i = -factor; i<= factor; i++)
                    {
                        for(int j = -factor; j<= factor; j++)
                        {
                            if((i + r) >= 0 && (i + r) < height &&  (j + c) < width && (j+c) >= 0)
                            {
                                temp.Add(base_img[c + j, i + r]);
                            }
                        }

                    }
                    var ordered_list = temp.OrderBy(o => (o.R * 3 + o.G * 2 + o.B * 1));
                    temp = ordered_list.ToList();
                    post_img[c,r] = temp[temp.Count / 2];

                }
            }*/
            #endregion
        }

        
        #endregion


        #region Grad Tasks

        /// <summary>
        /// This class function generates corner diagonal gradient image.
        /// </summary>
        /// <param name="image"></param>
        public static void CornerDiagonalGradient(RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;
            Point start_pt = new Point(height, 0.0);
            Point end_pt = new Point(0.0, width);
            double diag_length = Point.Subtract(end_pt,start_pt).Length;
            for (int r = 0; r < height; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    Point ortho_pt = ClosestPointToSegment(new Point(r, c), start_pt, end_pt);
                    image[c, r] = ColorHelpers.ColorAdd(
                        ColorHelpers.ColorMultiply((double)Point.Subtract(end_pt, ortho_pt).Length / diag_length, Color.FromArgb(255, 0, 0)),
                        ColorHelpers.ColorMultiply((double)Point.Subtract(ortho_pt, start_pt).Length / diag_length, Color.FromArgb(0, 255, 0)));
                }
            }
        }

        /// <summary>
        /// This class function calculates the color for given pixel in the image.
        /// </summary>
        public static Color ParallelMedianFilter(int c, int r, RasterImage image)
        {
            var temp = new List<Color>();
            int factor = 1;
            for (int i = -factor; i <= factor; i++)
            {
                for (int j = -factor; j <= factor; j++)
                {
                    if ((i + r) >= 0 && (i + r) < image.Height && (j + c) < image.Width && (j + c) >= 0)
                    {
                        temp.Add(image[c + j, i + r]);
                    }
                }

            }
            var ordered_list = temp.OrderBy(o => (o.R * 3 + o.G * 2 + o.B * 1));
            temp = ordered_list.ToList();
            return temp[temp.Count / 2];
        }

        /// <summary>
        /// This class function calculates the closest point from point P
        /// on the line formed by points A and B.
        /// </summary>
        /// <param name="P"></param>
        /// <param name="A"></param>
        /// <param name="B"></param>
        /// <returns></returns>
        private static Point ClosestPointToSegment(Point P, Point A, Point B)
        {
            Point a_to_p = new Point(P.X - A.X, P.Y - A.Y), a_to_b = new Point(B.X - A.X, B.Y - A.Y);

            double atb2 = a_to_b.X * a_to_b.X + a_to_b.Y * a_to_b.Y;
            double atp_dot_atb = a_to_p.X * a_to_b.X + a_to_p.Y * a_to_b.Y; 
            double t = atp_dot_atb / atb2;  
            return new Point(A.X + a_to_b.X * t, A.Y + a_to_b.Y * t);
        }
        #endregion
    }
}
