﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_Sharp_Check_In
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            lbl_text.Visible = false;
        }

        private void editBlue_Click(object sender, EventArgs e)
        {
            lbl_text.Visible = false;
            this.BackColor = Color.Blue;
            Invalidate();
        }

        private void editText_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            lbl_text.Visible = true;
            Invalidate();
        }
    }
}
