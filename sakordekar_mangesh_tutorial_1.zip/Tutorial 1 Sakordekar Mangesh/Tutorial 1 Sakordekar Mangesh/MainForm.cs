﻿/**
 * *************** File Header ****************************
 * 
 * File Name : MainForm.cs
 * 
 * Class: CSC 524 Digital Image Processing
 * 
 * Project: Tutorial 1
 * 
 * Author: Mangesh Sakordekar
 * 
 * Description:
 * This file contains code to handle the sections 1 to 12 of Tutorial 1.
 * 
 * Bugs/Errors: None
 * 
 * Grading:
 * __X__	35	Tutorial completed (if not, what was the last section completed)
 * __X__	5	Play menu option
 * __X__	5	Play Mine: Initially blank window
 * __X__	10	Play Mine: Plays sound at 0:03
 * __X__	10	Play Mine: Displays at 0:08
 * __X__	10	Play Mine: New image display at 0:12
 * __X__	5	Play Mine: Caption displays at 0:15
 * __X__	5	Play Mine: Second sound at 0:20
 * __X__	5	Play Mine: Blank and done at 0:30
 * __X__	10	Play Mine: Play works 2+ times
 * __X__    20	(CSC\CENG 524 ONLY) Looping task completed
 * 
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutorial_1_Sakordekar_Mangesh
{
    public partial class MainForm : Form
    {
        private enum States { Start, Splash, Smith, HearThat, Chill, Done };
        private States state;

        private Bitmap splash;
        private int splashwid;
        private int splashhit;

        private Bitmap smith;
        private Bitmap chill;

        private Timer aTimer;
        private bool firstdraw = true;
        private DateTime starttime;

        private Sequence sequence;
        private bool isSequence = false;

        private Grad grad;
        private bool isGrad = false;
        public MainForm()
        {
            InitializeComponent();
            splash = Properties.Resources.splash;
            smith = Properties.Resources.smith;
            chill = Properties.Resources.chill;
            splashwid = splash.Width;
            splashhit = splash.Height;
            state = States.Start;      // our initial state
            sequence = new Sequence();
            grad = new Grad();
            DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (isSequence)
            {
                sequence.OnDraw(ref e, ClientRectangle);
                return;
            }
            else if (isGrad)
            {
                grad.OnDraw(ref e, ClientRectangle);
                return;
            }

            if (firstdraw)
            {
                firstdraw = false;
                OnFirstDraw();
            }

            Graphics g = e.Graphics;
            Rectangle win = ClientRectangle;
            int x = win.Width / 2 - splashwid / 2;
            int y = win.Height / 2 - splashhit / 2;

            switch (state)
            {
                case States.Splash:
                    g.DrawImage(splash, new Point(x, y));
                    break;
                case States.Smith:
                case States.HearThat:
                    x = win.Width / 2 - smith.Width / 2;
                    y = win.Height / 2 - smith.Height / 2;
                    g.DrawImage(smith, x, y, smith.Width, smith.Height);
                    break;

                case States.Chill:
                    x = win.Width / 2 - chill.Width / 2;
                    y = win.Height / 2 - chill.Height / 2;
                    g.DrawImage(chill, x, y, chill.Width, chill.Height);
                    break;

                default:
                    // Display nothing
                    break;
            }
        }

        private void resize(object sender, EventArgs e)
        {
            Invalidate();
        }

        private void menuItemPlaySmith_Click(object sender, EventArgs e)
        {
            isSequence = false;
            isGrad = false;
            SoundPlayer player = new SoundPlayer(Properties.Resources.hearthat);
            player.Play();
        }

        private void OnFirstDraw()
        {
            starttime = DateTime.Now;

            aTimer = new Timer();
            aTimer.Interval = 1;
            aTimer.Tick += new EventHandler(TimerEvent);
            aTimer.Start();
        }

        private void TimerEvent(Object myObject, EventArgs myEventArgs)
        {
            // Force redraw whenever the timer fires
            Invalidate();

            if (isSequence)
            {
                sequence.TimerEventSeq(ref aTimer);
                return;
            }
            else if (isGrad)
            {
                grad.TimerEventSeq(ref aTimer);
                return;
            }
            // This will keep track of the relative time
            // to the next state.
            int nexteventtime = 0;

            switch (state)
            {
                case States.Start:
                    // If we are in the state state, just move directly
                    // to the Splash state
                    state = States.Splash;
                    nexteventtime = 1;
                    break;
                case States.Splash:
                    // The Splash state is ending, we are changing to the Smith state
                    state = States.Smith;
                    nexteventtime = 2;
                    break;

                case States.Smith:
                    // The Smith state is ending, we are changing to the HearThat state
                    state = States.HearThat;

                    // What we do at the end of state Smith, entering state HearThat
                    SoundPlayer player = new SoundPlayer(Properties.Resources.hearthat);
                    player.Play();

                    nexteventtime = 8;
                    break;

                case States.HearThat:
                    // What we at the end of state HearThat, entering state Chill
                    state = States.Chill;
                    nexteventtime = 12;
                    break;

                case States.Chill:
                    state = States.Done;
                    break;
            }

            // Only reset the timer if we are not done
            if (state != States.Done)
            {
                DateTime currenttime = DateTime.Now;
                DateTime nexttime = starttime.AddSeconds(nexteventtime);
                TimeSpan span = nexttime - currenttime;
                double tillnext = span.TotalMilliseconds > 1 ? span.TotalMilliseconds : 1;

                aTimer.Interval = (int)tillnext;
            }
            else
            {
                aTimer.Stop();
            }
        }

        private void menuItemPlayMine_Click(object sender, EventArgs e)
        {
            isGrad = false;
            aTimer.Stop();
            aTimer.Interval = 1;
            aTimer.Start();
            sequence.StartTimer();
            isSequence = true;
        }

        private void menuItemLoop_Click(object sender, EventArgs e)
        {
            isSequence = false;
            aTimer.Stop();
            aTimer.Interval = 1;
            aTimer.Start();
            grad.StartTimer();
            isGrad = true;
        }
    }
}
