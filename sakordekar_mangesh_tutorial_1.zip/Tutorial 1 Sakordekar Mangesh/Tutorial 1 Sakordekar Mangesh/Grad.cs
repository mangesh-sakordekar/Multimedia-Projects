﻿/**
 * *************** File Header ****************************
 * 
 * File Name : Grad.cs
 * 
 * Class: CSC 524 Digital Image Processing
 * 
 * Project: Tutorial 1
 * 
 * Author: Mangesh Sakordekar
 * 
 * Description:
 * This file contains code to handle the section 14 of Tutorial 1 
 * 
 * Bugs/Errors: None
 * 
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Windows.Forms;
using System.Media;

namespace Tutorial_1_Sakordekar_Mangesh
{
    internal class Grad
    {
        //State machine
        private enum States { Start, PeterLeft, PeterSound1, PeterFly, PeterSound2, Glen, Giggity, Done };
        private States state;

        //Images required
        private Bitmap peter_left = Properties.Resources.peter_left;
        private Bitmap peter_fly = Properties.Resources.peter_fly;
        private Bitmap glen = Properties.Resources.glen;

        //start time for the loop sequence
        private DateTime starttime;

        //variable to keep track of loops
        private double loop_cnt = 0;

        /**
         * public Void StartTimer()
         * 
         * Description:
         * Sets the start time for the looping sequence.
         */
        public void StartTimer()
        {
            state = States.Start;
            starttime = DateTime.Now;
            loop_cnt = 0;
        }

        /**
         * public void OnDraw(ref PaintEventArgs e, Rectangle win)
         * 
         * description:
         * Draws the appropriate image according to the current 
         * state of the stae machine.
         */
        public void OnDraw(ref PaintEventArgs e, Rectangle win)
        {
            Graphics g = e.Graphics;
            int x = win.Width / 2;
            int y = win.Height / 2;

            switch (state)
            {
                case States.PeterLeft:
                case States.PeterSound1:
                    g.DrawImage(peter_left, x-peter_left.Width/2, y-peter_left.Height/2, peter_left.Width, peter_left.Height);
                    break;

                case States.PeterFly:
                case States.PeterSound2:
                    g.DrawImage(peter_fly, x - peter_fly.Width / 2, y - peter_fly.Height / 2, peter_fly.Width, peter_fly.Height);
                    break;

                case States.Glen:
                case States.Giggity:
                    g.DrawImage(glen, x - glen.Width / 2, y - glen.Height / 2, glen.Width, glen.Height);
                    break;

                default:
                    // Display nothing
                    break;
            }
        }

        /**
         * public Void TimerEventSeq(ref Timer aTimer)
         * 
         * Description:
         * Called when the interval of the timer is up. 
         * Sets the state machine to the next state and 
         * plays sounds if required.
         */
        public void TimerEventSeq(ref Timer aTimer)
        {
            double nexteventtime = 0;
            SoundPlayer player;
            switch (state)
            {
                case States.Start:
                    state = States.PeterLeft;
                    nexteventtime = 1;
                    break;

                case States.PeterLeft:
                    state = States.PeterSound1;
                    player = new SoundPlayer(Properties.Resources.peter1);
                    player.Play();
                    nexteventtime = 2;
                    break;

                case States.PeterSound1:
                    state = States.PeterFly;
                    nexteventtime = 2.5;
                    break;

                case States.PeterFly:
                    state = States.PeterSound2;
                    player = new SoundPlayer(Properties.Resources.peter2);
                    player.Play();
                    nexteventtime = 4;
                    break;

                case States.PeterSound2:
                    state = States.Glen;
                    nexteventtime = 4.5;
                    break;

                case States.Glen:
                    state = States.Giggity;
                    player = new SoundPlayer(Properties.Resources.gigity);
                    player.Play();
                    nexteventtime = 6;
                    break;

                case States.Giggity:
                    //state = States.Done;
                    state = States.PeterLeft;
                    break;
            }

            if (state == States.Giggity)
            {
                loop_cnt += nexteventtime;
                nexteventtime = 0;
            }

            DateTime currenttime = DateTime.Now;
            DateTime nexttime = starttime.AddSeconds(loop_cnt + nexteventtime);
            TimeSpan span = nexttime - currenttime;
            double tillnext = span.TotalMilliseconds > 1 ? span.TotalMilliseconds : 1;

            aTimer.Interval = (int)tillnext;

            if(state == States.Done)
            {
                aTimer.Stop();
            }
        }
    }
}
