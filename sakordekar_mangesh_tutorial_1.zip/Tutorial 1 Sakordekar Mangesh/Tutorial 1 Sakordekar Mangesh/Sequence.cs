﻿/**
 * *************** File Header ****************************
 * 
 * File Name : Sequence.cs
 * 
 * Class: CSC 524 Digital Image Processing
 * 
 * Project: Tutorial 1
 * 
 * Author: Mangesh Sakordekar
 * 
 * Description:
 * This file contains code to handle the section 13 of Tutorial 1. 
 * 
 * Bugs/Errors: None
 * 
 */


using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutorial_1_Sakordekar_Mangesh
{
    internal class Sequence
    {
        //State machine
        private enum States { Start, Blank, Entry, Intro, Bat, Cap, Exit, Done };
        private States state;

        //Class Variables
        private Bitmap batman;
        private int batwid;
        private int bathit;
        private string caption = "'Use GUI' - Batman, 2022";
        private string intro_txt = "Use GUI by Mangesh";

        //Tools to draw and write
        Pen p = new Pen(Color.Blue, 10);
        Font fnt = new Font("Arial", 15, FontStyle.Bold | FontStyle.Italic);
        Brush brush = new SolidBrush(Color.Black);

        //Start time for this section
        private DateTime starttime;


        public Sequence()
        {
            batman = Properties.Resources.batman;
            batwid = batman.Width;
            bathit = batman.Height;
        }

        /**
         * public Void StartTimer()
         * 
         * Description:
         * Sets the start time for the sequence.
         */
        public void StartTimer()
        {
            state = States.Start;
            starttime = DateTime.Now;
        }

        /**
         * public void OnDraw(ref PaintEventArgs e, Rectangle win)
         * 
         * description:
         * Draws the appropriate image according to the current 
         * state of the stae machine.
         */
        public void OnDraw(ref PaintEventArgs e, Rectangle win)
        {
            Graphics g = e.Graphics;
            int x = win.Width / 2 - batwid / 2;
            int y = win.Height / 2 - bathit / 2;

            switch (state)
            {
                case States.Intro:
                    Rectangle r = new Rectangle(x, y, batwid, bathit);
                    g.DrawRectangle(p,r);
                    g.DrawString(intro_txt, fnt, brush, x + batwid / 4, y + bathit / 2);
                    break;
         
                case States.Bat:
                    g.DrawImage(batman, x, y, batwid, bathit);
                    break;

                case States.Exit:
                case States.Cap:
                    g.DrawImage(batman, x, y, batwid, bathit);
                    g.DrawString(caption, fnt, brush, x + batwid/4, y + bathit);
                    break;

                default:
                    // Display nothing
                    break;
            }
        }


        /**
         * public Void TimerEventSeq(ref Timer aTimer)
         * 
         * Description:
         * Called when the interval of the timer is up. 
         * Sets the state machine to the next state and 
         * plays sounds if required.
         */
        public void TimerEventSeq(ref Timer aTimer)
        {
            int nexteventtime = 0;
            SoundPlayer player;
            switch (state)
            {
                case States.Start:
                    state = States.Blank;
                    nexteventtime = 3;
                    break;

                case States.Blank:
                    // If we are in the state state, just move directly
                    // to the Splash state
                    state = States.Entry;
                    player = new SoundPlayer(Properties.Resources.entry);
                    player.Play();
                    nexteventtime = 8;
                    break;

                case States.Entry:
                    // The Splash state is ending, we are changing to the Smith state
                    state = States.Intro;
                    nexteventtime = 12;
                    break;

                case States.Intro:
                    // The Smith state is ending, we are changing to the HearThat state
                    state = States.Bat;
                    nexteventtime = 15;
                    break;

                case States.Bat:
                    // What we at the end of state HearThat, entering state Chill
                    state = States.Cap;
                    nexteventtime = 20;
                    break;

                case States.Cap:
                    // What we at the end of state HearThat, entering state Chill
                    state = States.Exit;
                    player = new SoundPlayer(Properties.Resources.exit);
                    player.Play();
                    nexteventtime = 30;
                    break;

                case States.Exit:
                    state = States.Done;
                    break;
            }

            // Only reset the timer if we are not done
            if (state != States.Done)
            {
                DateTime currenttime = DateTime.Now;
                DateTime nexttime = starttime.AddSeconds(nexteventtime);
                TimeSpan span = nexttime - currenttime;
                double tillnext = span.TotalMilliseconds > 1 ? span.TotalMilliseconds : 1;

                aTimer.Interval = (int)tillnext;
            }
            else
            {
                aTimer.Stop();
            }
        }
    }
}
