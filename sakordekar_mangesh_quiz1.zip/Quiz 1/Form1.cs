﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media;
using Matrix = System.Windows.Media.Matrix;

namespace Quiz_1
{
    public partial class MainForm : Form
    {
        private RasterImage image;
        private RasterImage lastImage;

        public MainForm()
        {
            InitializeComponent();
            DoubleBuffered = true;
        }

        //main Paint function
        protected override void OnPaint(PaintEventArgs e)
        {
            if (image == null)
                return;

            Graphics g = e.Graphics;

            g.DrawImage(image.toBitmap, 0, menuStrip1.Height);

        }

        private void open_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                image = new RasterImage(new Bitmap(openFileDialog.FileName));
                lastImage = new RasterImage(image);
                Invalidate();
            }
        }

        private void reset_Click(object sender, EventArgs e)
        {
            if (lastImage != null)
                image = new RasterImage(lastImage);
            Invalidate();
        }

        private void sample1_Click(object sender, EventArgs e)
        {
            image = new RasterImage(new Bitmap(Properties.Resources.Stickman));
            lastImage = new RasterImage(image);
            Invalidate();
        }
        private void sample2_Click(object sender, EventArgs e)
        {
            image = new RasterImage(new Bitmap(Properties.Resources.Leaf));
            lastImage = new RasterImage(image);
            Invalidate();
        }

        private void task1_Click(object sender, EventArgs e)
        {
            image = new RasterImage(200, 200);
            for (int r = 0; r < 200; r++)
            {
                for (int c = 0; c < 200; c++)
                {
                    image[c, r] = Color.FromArgb(100, 90, 75);
                }
            }
            Invalidate();
        }

        private void task2_Click(object sender, EventArgs e)
        {
            //image = Filter3x3(image);
            int height = image.Height;
            int width = image.Width;

            int[,] pts = new int[4, 2]
            {
                {0, 0},
                {1, 0},
                {0, 1},
                {0, 2},
            };

            for(int i = 0; i<4; i++)
            {
                for (int r = pts[i,0], c = pts[i,1]; r < height && c < width; r++, c++)
                {
                    image[c, r] = Color.DarkOrange;
                }
            }
            


            Invalidate();

        }

        private void task3_Click(object sender, EventArgs e)
        {
            image = Task3a(image);
            /*** Task 3 b
            RasterImage temp = new RasterImage(image);

            int height = image.Height;
            int width = image.Width;

            for(int r = 0; r < height; r++)
            {
                for(int c = 0; c < width; c++)
                {
                    double X, Y;
                    if(r < height / 2)
                    {
                        X = (double)c / 2.0;
                        Y = r + (double)c / 10.0;
                    }
                    else
                    {
                        X = c - 40;
                        Y = r;
                    }


                    temp[c, r] = BilinearInterpolate(X, Y, image);
                }
            }
            image = temp;
            */
            Invalidate();
        }


        
        private void task4_Click(object sender, EventArgs e)
        {
            //undergraduate
            RasterImage mask = new RasterImage(new Bitmap(Properties.Resources.Mask));

            //Graduate
            RasterImage mask2 = new RasterImage(new Bitmap(Properties.Resources.Mask2));

            for (int r = 0; r < image.Height; r++)
            {
                for (int c = 0; c < image.Width; c++)
                {
                    int A = (image[c, r].A * mask2[c, r].A) / 255;
                    int R = (image[c, r].R * mask2[c, r].R) / 255;
                    int G = (image[c, r].G * mask2[c, r].G) / 255;
                    int B = (image[c, r].B * mask2[c, r].B) / 255;
                    image[c, r] = Color.FromArgb(A, R, G, B);
                  
                }
            }
            Invalidate();
        }

        public static RasterImage Task3a(RasterImage image)
        {
            RasterImage postImage = new RasterImage(image);
            int height = image.Height;
            int width = image.Width;


            //loop over pixels
            for (int r = 0; r < height; r+=10)
            {
                for (int c = 0; c < width; c+=10)
                {
                    Color pixel = Color.Black;
                    double tallyR = 0;
                    double tallyG = 0;
                    double tallyB = 0;
                    int cnt = 0;
                    //loop over square around this pixel, watching boundaries
                    for (int i = r; i < Math.Min(height, r+10); i++)
                    {

                        for (int j = c; j < Math.Min(width, c+10); j++)
                        {
                            //tally channels
                            pixel = image[j, i];
                            tallyR += pixel.R ;
                            tallyG += pixel.G ;
                            tallyB += pixel.B ;
                            cnt++;
                        }
                    }

                    pixel = Color.FromArgb(
                                ColorHelpers.ClampColorElem(tallyR / (double)cnt),
                                ColorHelpers.ClampColorElem(tallyG / (double)cnt),
                                ColorHelpers.ClampColorElem(tallyB / (double)cnt)
                                );
                    for (int i = r; i < Math.Min(height, r + 10); i++)
                    {

                        for (int j = c; j < Math.Min(width, c + 10); j++)
                        {
                            
                            postImage[j, i] = pixel;
                        }
                    }
                    //average values, and set
                    

                }
            }

            return postImage;
        }

        public Color BilinearInterpolate(double x, double y, RasterImage source)
        {
            int ix = (int)(x);
            double ixf = x - ix;      // Fractional part
            int iy = (int)(y);
            double iyf = y - iy;

            //check bounds
            if (ix >= 0 && ix < source.Width - 1 &&
                       iy >= 0 && iy < source.Height - 1)
            {
                //grab neighboring pixels
                Color upLeft = source[ix, iy];
                Color lowLeft = source[ix, iy + 1];
                Color upRight = source[ix + 1, iy];
                Color lowRight = source[ix + 1, iy + 1];

                //interpolate colors based on fractional part
                Color temp = ColorHelpers.ColorMultiply((1.0 - ixf) * (1.0 - iyf), upLeft);
                temp = ColorHelpers.ColorAdd(temp, ColorHelpers.ColorMultiply((1.0 - ixf) * iyf, lowLeft));
                temp = ColorHelpers.ColorAdd(temp, ColorHelpers.ColorMultiply(ixf * (1.0 - iyf), upRight));
                temp = ColorHelpers.ColorAdd(temp, ColorHelpers.ColorMultiply(ixf * iyf, lowRight));

                return temp;
            }
            else
            {
                //out of bounds
                return Color.White;
            }
        }

    }
}
