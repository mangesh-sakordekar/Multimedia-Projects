﻿/**
 * LinearWarp.cs
 * This file defines class LinearWarp wwhich contains all the functions to perform
 * linear warping tasks
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageProcess
{
    internal class LinearWarp
    {
        /// <summary>
        /// This function translates the top half of the image to the
        /// right by half its width
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color TranslateTopHalf(int c, int r, RasterImage image)
        {
            int half_height = image.Height / 2;
            int half_width = image.Width/ 2;

            if (r < half_height) {
                if (c - half_width >= 0)
                    return image[c - half_width, r];
                return Color.White;
            }

            return image[c,r];
        }

        /// <summary>
        /// This function moves the pixels along the width of the image 
        /// according to sime curve
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color SineWave(int c, int r, RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            int rr = (int)(r + 20 * Math.Sin((c * 2 * Math.PI) / 180.0));
            if (rr >= 0 && rr < height)
                return image[c, rr];
            return Color.White;
        }
    }
}
