﻿/**
 * NonLineraWarp.cs
 * This file defines class NonLinearWarp wwhich contains all the functions to perform
 * non linear warping tasks
 */

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageProcess
{
    internal class NonLinearWarp
    {
        /// <summary>
        /// Converts the image into a triangle with vertices at bottom left corner, bottom right corner 
        /// and center of the first row of pixels.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color MakeTriangle(int c, int r, RasterImage image)
        {
            double height = image.Height ;
            double width = image.Width;
            double w2 = width/2 ;
            int cc;

            if (c < width / 2)
            {
                cc = (int)(w2 - ((w2 - c) * w2) / ((w2 * (height-r)) / height));
                
                if (cc < 0)
                    return Color.White;

                return image[cc, r];
            }

            cc = (int)(w2 + ((c - w2) * w2) / ((w2 * (height-r)) / height));
            
            if (cc >= width)
                return Color.White;

            return image[cc, r];

        }

        /// <summary>
        /// Converts the image into a diamond with vertices at the center of each 
        /// edge of the image.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color MakeDiamond(int c, int r, RasterImage image)
        {
            double  height = image.Height;
            double  width = image.Width;

            double  h2 = height / 2;
            double w2 = width / 2;

            if(r < height / 2)
            {
                if(c < width / 2)
                {
                    int cc = (int)(w2 -  ((w2-c) * w2) / ((w2 * (r+1)) / h2));
                    
                    if (cc < 0)
                        return Color.White;

                    return image[cc, r];
                }
                else
                {
                    int cc = (int)(w2 + ((c - w2) * w2) / ((w2 * (r+1)) / h2));
                    if (cc >= width)
                        return Color.White;

                    return image[cc, r];
                }
            }
            else
            {
                if (c < width / 2)
                {
                    int cc = (int)(w2 - ((w2 - c) * w2) / ((w2 * (height - r)) / h2));
                    if (cc < 0)
                        return Color.White;

                    return image[cc, r];
                }
                else
                {
                    int cc = (int)(w2 + ((c-w2) * w2) / ((w2 * (height - r)) / h2));
                    if (cc >= width)
                        return Color.White;

                    return image[cc, r];
                }
            }

            return Color.White;
        }


        //Bilinear Interpolation 
        public static Color BilinearInterpolate(double x, double y, RasterImage source)
        {
            int ix = (int)(x);
            double ixf = x - ix;      // Fractional part
            int iy = (int)(y);
            double iyf = y - iy;

            //check bounds
            if (ix >= 0 && ix < source.Width - 1 &&
                       iy >= 0 && iy < source.Height - 1)
            {
                //grab neighboring pixels
                Color upLeft = source[ix, iy];
                Color lowLeft = source[ix, iy + 1];
                Color upRight = source[ix + 1, iy];
                Color lowRight = source[ix + 1, iy + 1];

                //interpolate colors based on fractional part
                Color temp = ColorHelpers.ColorMultiply((1.0 - ixf) * (1.0 - iyf), upLeft);
                temp = ColorHelpers.ColorAdd(temp, ColorHelpers.ColorMultiply((1.0 - ixf) * iyf, lowLeft));
                temp = ColorHelpers.ColorAdd(temp, ColorHelpers.ColorMultiply(ixf * (1.0 - iyf), upRight));
                temp = ColorHelpers.ColorAdd(temp, ColorHelpers.ColorMultiply(ixf * iyf, lowRight));

                return temp;
            }
            else
            {
                //out of bounds
                return Color.White;
            }
        }
    }
}
