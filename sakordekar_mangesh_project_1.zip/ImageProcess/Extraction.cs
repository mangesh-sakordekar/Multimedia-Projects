﻿/**
 * 
 * Extraction.cs
 * This file contains the class Extaction which contains funtions for
 * all the extraction tasks.
 * 
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageProcess
{
    internal class Extraction
    {
        private static double[,] filterSobelVertical = new double[5, 5]
            {
                {-3, -1, 0, 1, 3},
                {-6, -2, 0, 2, 6},
                {-9, -3, 0, 3, 9},
                {-6, -2, 0, 2, 6},
                {-3, -1, 0, 1, 3},
            };

        private static double[,] filterSobelHorizontal = new double[5, 5]
            {
                {3, 6, 9, 6, 3},
                {1, 2, 3, 2, 1},
                {0, 0, 0, 0, 0},
                {-1, -2, -3, -2, -1},
                {-3, -6, -9, -6, -3},
            };

        /// <summary>
        /// This function implements the Sobel 5 by 5 filter for edge detection.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color Sobel5x5Parellel(int c, int r, RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            double threshhold = 500.0;

            int range = 2;

            Color pixel = Color.Black;
            double tallyH = 0;
            double tallyV = 0;


            //loop over square around this pixel, watching boundaries
            for (int i = -range; i <= range; i++)
            {
                if ((r + i) >= 0 && (r + i) < height)
                {

                    for (int j = -range; j <= range; j++)
                    {
                        if ((c + j) >= 0 && (c + j) < width)
                        {
                            //tally channels
                            pixel = image[c + j, r + i];
                            tallyH += (pixel.R + pixel.G + pixel.B) / 3.0 * filterSobelVertical[i + range, j + range];
                            tallyV += (pixel.R + pixel.G + pixel.B) / 3.0 * filterSobelHorizontal[i + range, j + range];

                        }
                    }
                }
            }

            //average values, and set
            if (Math.Abs(tallyH) + Math.Abs(tallyV) > threshhold)
                return ColorHelpers.ColorMultiply((Math.Abs(tallyH) + Math.Abs(tallyV)) * 0.0002, Color.White);

            return Color.Black;
        }

        /// <summary>
        /// Swaps the red and green channel for each pixel
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color SwapRedGreen(int c, int r, RasterImage image)
        {
            return Color.FromArgb(image[c, r].G, image[c, r].R, image[c, r].B);
        }

        /// <summary>
        /// Keeps only the blue value of the pixel and sets red and geen to 0
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color ColorFilter(int c, int r, RasterImage image)
        {
            return Color.FromArgb(0, 0, image[c, r].B);
        }

    }
}
