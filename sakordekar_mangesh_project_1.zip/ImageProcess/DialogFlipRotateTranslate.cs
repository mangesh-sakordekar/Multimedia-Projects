﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcess
{
    /// <summary>
    /// Dialog box to read in angle, x value and y value 
    /// for flip-rotate-translate task
    /// </summary>
    public partial class DialogFlipRotateTranslate : Form
    {
        public double Angle
        {
            get { return Convert.ToDouble(angleBox.Text); }
            set { xBox.Text = value.ToString(); }
        }
        public int X
        {
            get { return Convert.ToInt32(xBox.Text); }
            set { xBox.Text = value.ToString(); }
        }
        public int Y
        {
            get { return Convert.ToInt32(yBox.Text); }
            set { yBox.Text = value.ToString(); }
        }


        public DialogFlipRotateTranslate()
        {
            InitializeComponent();
        }
    }
}
