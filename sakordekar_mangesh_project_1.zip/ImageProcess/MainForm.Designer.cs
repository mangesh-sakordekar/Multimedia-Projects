﻿namespace ImageProcess
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.openTestMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.openMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.closeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.coreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sharpenFilter3x3CoreOption = new System.Windows.Forms.ToolStripMenuItem();
            this.prewittFilter5x5CoreOption = new System.Windows.Forms.ToolStripMenuItem();
            this.quarterCircleCoreOption = new System.Windows.Forms.ToolStripMenuItem();
            this.flipRotateTranslateCoreOption = new System.Windows.Forms.ToolStripMenuItem();
            this.gradientOverlayCoreOption = new System.Windows.Forms.ToolStripMenuItem();
            this.oilPaintTextureCoreOption = new System.Windows.Forms.ToolStripMenuItem();
            this.basicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gaussianBlurBasicOption = new System.Windows.Forms.ToolStripMenuItem();
            this.extractionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobelFilter5x5ExtractionOption = new System.Windows.Forms.ToolStripMenuItem();
            this.swapRedGreenExtractionOption = new System.Windows.Forms.ToolStripMenuItem();
            this.blueColorFilterExtractionOption = new System.Windows.Forms.ToolStripMenuItem();
            this.linearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flipTopHalfLinearOption = new System.Windows.Forms.ToolStripMenuItem();
            this.sineWaveLinearOption = new System.Windows.Forms.ToolStripMenuItem();
            this.nonLinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeTriangeNonLinearOption = new System.Windows.Forms.ToolStripMenuItem();
            this.makeDiamondNonLinearOption = new System.Windows.Forms.ToolStripMenuItem();
            this.miscToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gradientStripeOverlayOption = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.copyMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.thresholdMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.warpNearestMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.warpBilenearMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.processMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.fillWhiteMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.negativeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.drawMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.generateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.generateToolStripMenuItem,
            this.processMenu,
            this.coreToolStripMenuItem,
            this.basicToolStripMenuItem,
            this.extractionToolStripMenuItem,
            this.linearToolStripMenuItem,
            this.nonLinearToolStripMenuItem,
            this.miscToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newMenu,
            this.openTestMenu,
            this.openMenu,
            this.saveMenu,
            this.closeMenu,
            this.exitMenu});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newMenu
            // 
            this.newMenu.Name = "newMenu";
            this.newMenu.Size = new System.Drawing.Size(180, 22);
            this.newMenu.Text = "&New";
            this.newMenu.Click += new System.EventHandler(this.newMenu_Click);
            // 
            // openTestMenu
            // 
            this.openTestMenu.Name = "openTestMenu";
            this.openTestMenu.Size = new System.Drawing.Size(180, 22);
            this.openTestMenu.Text = "Open &Test";
            this.openTestMenu.Click += new System.EventHandler(this.openTestMenu_Click);
            // 
            // openMenu
            // 
            this.openMenu.Name = "openMenu";
            this.openMenu.Size = new System.Drawing.Size(180, 22);
            this.openMenu.Text = "&Open";
            this.openMenu.Click += new System.EventHandler(this.openMenu_Click);
            // 
            // saveMenu
            // 
            this.saveMenu.Name = "saveMenu";
            this.saveMenu.Size = new System.Drawing.Size(180, 22);
            this.saveMenu.Text = "&Save";
            this.saveMenu.Click += new System.EventHandler(this.saveMenu_Click);
            // 
            // closeMenu
            // 
            this.closeMenu.Name = "closeMenu";
            this.closeMenu.Size = new System.Drawing.Size(180, 22);
            this.closeMenu.Text = "&Close";
            this.closeMenu.Click += new System.EventHandler(this.closeMenu_Click);
            // 
            // exitMenu
            // 
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(180, 22);
            this.exitMenu.Text = "&Exit";
            this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
            // 
            // coreToolStripMenuItem
            // 
            this.coreToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sharpenFilter3x3CoreOption,
            this.prewittFilter5x5CoreOption,
            this.quarterCircleCoreOption,
            this.flipRotateTranslateCoreOption,
            this.gradientOverlayCoreOption,
            this.oilPaintTextureCoreOption});
            this.coreToolStripMenuItem.Name = "coreToolStripMenuItem";
            this.coreToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.coreToolStripMenuItem.Text = "Core";
            // 
            // sharpenFilter3x3CoreOption
            // 
            this.sharpenFilter3x3CoreOption.Name = "sharpenFilter3x3CoreOption";
            this.sharpenFilter3x3CoreOption.Size = new System.Drawing.Size(180, 22);
            this.sharpenFilter3x3CoreOption.Text = "Sharpen Filter (3x3)";
            this.sharpenFilter3x3CoreOption.Click += new System.EventHandler(this.sharpenFilter3x3CoreOption_Click);
            // 
            // prewittFilter5x5CoreOption
            // 
            this.prewittFilter5x5CoreOption.Name = "prewittFilter5x5CoreOption";
            this.prewittFilter5x5CoreOption.Size = new System.Drawing.Size(180, 22);
            this.prewittFilter5x5CoreOption.Text = "Prewitt Filter (5x5)";
            this.prewittFilter5x5CoreOption.Click += new System.EventHandler(this.prewittFilter5x5CoreOption_Click);
            // 
            // quarterCircleCoreOption
            // 
            this.quarterCircleCoreOption.Name = "quarterCircleCoreOption";
            this.quarterCircleCoreOption.Size = new System.Drawing.Size(180, 22);
            this.quarterCircleCoreOption.Text = "Quarter Circle";
            this.quarterCircleCoreOption.Click += new System.EventHandler(this.quarterCircleCoreOption_Click);
            // 
            // flipRotateTranslateCoreOption
            // 
            this.flipRotateTranslateCoreOption.Name = "flipRotateTranslateCoreOption";
            this.flipRotateTranslateCoreOption.Size = new System.Drawing.Size(180, 22);
            this.flipRotateTranslateCoreOption.Text = "Flip Rotate Translate";
            this.flipRotateTranslateCoreOption.Click += new System.EventHandler(this.flipRotateTranslateCoreOption_Click);
            // 
            // gradientOverlayCoreOption
            // 
            this.gradientOverlayCoreOption.Name = "gradientOverlayCoreOption";
            this.gradientOverlayCoreOption.Size = new System.Drawing.Size(180, 22);
            this.gradientOverlayCoreOption.Text = "Gradient Overlay";
            this.gradientOverlayCoreOption.Click += new System.EventHandler(this.gradientOverlayCoreOption_Click);
            // 
            // oilPaintTextureCoreOption
            // 
            this.oilPaintTextureCoreOption.Name = "oilPaintTextureCoreOption";
            this.oilPaintTextureCoreOption.Size = new System.Drawing.Size(180, 22);
            this.oilPaintTextureCoreOption.Text = "Oil Paint Texture";
            this.oilPaintTextureCoreOption.Click += new System.EventHandler(this.oilPaintTextureCoreOption_Click);
            // 
            // basicToolStripMenuItem
            // 
            this.basicToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gaussianBlurBasicOption});
            this.basicToolStripMenuItem.Name = "basicToolStripMenuItem";
            this.basicToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.basicToolStripMenuItem.Text = "Basic";
            // 
            // gaussianBlurBasicOption
            // 
            this.gaussianBlurBasicOption.Name = "gaussianBlurBasicOption";
            this.gaussianBlurBasicOption.Size = new System.Drawing.Size(145, 22);
            this.gaussianBlurBasicOption.Text = "Gaussian Blur";
            this.gaussianBlurBasicOption.Click += new System.EventHandler(this.gaussianBlurBasicOption_Click);
            // 
            // extractionToolStripMenuItem
            // 
            this.extractionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobelFilter5x5ExtractionOption,
            this.swapRedGreenExtractionOption,
            this.blueColorFilterExtractionOption});
            this.extractionToolStripMenuItem.Name = "extractionToolStripMenuItem";
            this.extractionToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.extractionToolStripMenuItem.Text = "Extraction";
            // 
            // sobelFilter5x5ExtractionOption
            // 
            this.sobelFilter5x5ExtractionOption.Name = "sobelFilter5x5ExtractionOption";
            this.sobelFilter5x5ExtractionOption.Size = new System.Drawing.Size(161, 22);
            this.sobelFilter5x5ExtractionOption.Text = "Sobel Filter (5x5)";
            this.sobelFilter5x5ExtractionOption.Click += new System.EventHandler(this.sobelFilter5x5ExtractionOption_Click);
            // 
            // swapRedGreenExtractionOption
            // 
            this.swapRedGreenExtractionOption.Name = "swapRedGreenExtractionOption";
            this.swapRedGreenExtractionOption.Size = new System.Drawing.Size(161, 22);
            this.swapRedGreenExtractionOption.Text = "Swap Red Green";
            this.swapRedGreenExtractionOption.Click += new System.EventHandler(this.swapRedGreenExtractionOption_Click);
            // 
            // blueColorFilterExtractionOption
            // 
            this.blueColorFilterExtractionOption.Name = "blueColorFilterExtractionOption";
            this.blueColorFilterExtractionOption.Size = new System.Drawing.Size(161, 22);
            this.blueColorFilterExtractionOption.Text = "Blue Color Filter";
            this.blueColorFilterExtractionOption.Click += new System.EventHandler(this.blueColorFilterExtractionOption_Click);
            // 
            // linearToolStripMenuItem
            // 
            this.linearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.flipTopHalfLinearOption,
            this.sineWaveLinearOption});
            this.linearToolStripMenuItem.Name = "linearToolStripMenuItem";
            this.linearToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.linearToolStripMenuItem.Text = "Linear";
            // 
            // flipTopHalfLinearOption
            // 
            this.flipTopHalfLinearOption.Name = "flipTopHalfLinearOption";
            this.flipTopHalfLinearOption.Size = new System.Drawing.Size(180, 22);
            this.flipTopHalfLinearOption.Text = "Translate Top Half";
            this.flipTopHalfLinearOption.Click += new System.EventHandler(this.translateTopHalfLinearOption_Click);
            // 
            // sineWaveLinearOption
            // 
            this.sineWaveLinearOption.Name = "sineWaveLinearOption";
            this.sineWaveLinearOption.Size = new System.Drawing.Size(180, 22);
            this.sineWaveLinearOption.Text = "Sine Wave";
            this.sineWaveLinearOption.Click += new System.EventHandler(this.sineWaveLinearOption_Click);
            // 
            // nonLinearToolStripMenuItem
            // 
            this.nonLinearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.makeTriangeNonLinearOption,
            this.makeDiamondNonLinearOption});
            this.nonLinearToolStripMenuItem.Name = "nonLinearToolStripMenuItem";
            this.nonLinearToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.nonLinearToolStripMenuItem.Text = "Non-Linear";
            // 
            // makeTriangeNonLinearOption
            // 
            this.makeTriangeNonLinearOption.Name = "makeTriangeNonLinearOption";
            this.makeTriangeNonLinearOption.Size = new System.Drawing.Size(180, 22);
            this.makeTriangeNonLinearOption.Text = "MakeTriangle";
            this.makeTriangeNonLinearOption.Click += new System.EventHandler(this.makeTriangeNonLinearOption_Click);
            // 
            // makeDiamondNonLinearOption
            // 
            this.makeDiamondNonLinearOption.Name = "makeDiamondNonLinearOption";
            this.makeDiamondNonLinearOption.Size = new System.Drawing.Size(180, 22);
            this.makeDiamondNonLinearOption.Text = "Make Diamond";
            this.makeDiamondNonLinearOption.Click += new System.EventHandler(this.makeDiamondNonLinearOption_Click);
            // 
            // miscToolStripMenuItem
            // 
            this.miscToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gradientStripeOverlayOption});
            this.miscToolStripMenuItem.Name = "miscToolStripMenuItem";
            this.miscToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.miscToolStripMenuItem.Text = "Overlay";
            // 
            // gradientStripeOverlayOption
            // 
            this.gradientStripeOverlayOption.Name = "gradientStripeOverlayOption";
            this.gradientStripeOverlayOption.Size = new System.Drawing.Size(195, 22);
            this.gradientStripeOverlayOption.Text = "Gradient Stripe Overlay";
            this.gradientStripeOverlayOption.Click += new System.EventHandler(this.gradientStripeOverlayOption_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "JPEG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|PNG Files (*.png)|*.png|BMP File" +
    "s (*.bmp)|*p.bmp|All files (*.*)|*.*";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "JPEG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|PNG Files (*.png)|*.png|BMP File" +
    "s (*.bmp)|*.bmp";
            // 
            // copyMenu
            // 
            this.copyMenu.Name = "copyMenu";
            this.copyMenu.Size = new System.Drawing.Size(180, 22);
            this.copyMenu.Text = "&Copy";
            this.copyMenu.Click += new System.EventHandler(this.copyMenu_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(177, 6);
            // 
            // thresholdMenu
            // 
            this.thresholdMenu.Name = "thresholdMenu";
            this.thresholdMenu.Size = new System.Drawing.Size(180, 22);
            this.thresholdMenu.Text = "&Threshold";
            this.thresholdMenu.Click += new System.EventHandler(this.thresholdMenu_Click);
            // 
            // warpNearestMenu
            // 
            this.warpNearestMenu.Name = "warpNearestMenu";
            this.warpNearestMenu.Size = new System.Drawing.Size(180, 22);
            this.warpNearestMenu.Text = "&Warp Nearest";
            this.warpNearestMenu.Click += new System.EventHandler(this.warpNearestMenu_Click);
            // 
            // warpBilenearMenu
            // 
            this.warpBilenearMenu.Name = "warpBilenearMenu";
            this.warpBilenearMenu.Size = new System.Drawing.Size(180, 22);
            this.warpBilenearMenu.Text = "Warp &Bilenear";
            this.warpBilenearMenu.Click += new System.EventHandler(this.warpBilenearMenu_Click);
            // 
            // processMenu
            // 
            this.processMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyMenu,
            this.toolStripSeparator2,
            this.thresholdMenu,
            this.warpNearestMenu,
            this.warpBilenearMenu});
            this.processMenu.Name = "processMenu";
            this.processMenu.Size = new System.Drawing.Size(66, 20);
            this.processMenu.Text = "&Generate";
            // 
            // fillWhiteMenu
            // 
            this.fillWhiteMenu.Name = "fillWhiteMenu";
            this.fillWhiteMenu.Size = new System.Drawing.Size(180, 22);
            this.fillWhiteMenu.Text = "&Fill White";
            this.fillWhiteMenu.Click += new System.EventHandler(this.fillWhiteMenu_Click);
            // 
            // negativeMenu
            // 
            this.negativeMenu.Name = "negativeMenu";
            this.negativeMenu.Size = new System.Drawing.Size(180, 22);
            this.negativeMenu.Text = "&Negative";
            this.negativeMenu.Click += new System.EventHandler(this.negativeMenu_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // drawMenu
            // 
            this.drawMenu.Name = "drawMenu";
            this.drawMenu.Size = new System.Drawing.Size(180, 22);
            this.drawMenu.Text = "&Draw";
            this.drawMenu.Click += new System.EventHandler(this.drawMenu_Click);
            // 
            // generateToolStripMenuItem
            // 
            this.generateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillWhiteMenu,
            this.negativeMenu,
            this.toolStripSeparator1,
            this.drawMenu});
            this.generateToolStripMenuItem.Name = "generateToolStripMenuItem";
            this.generateToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.generateToolStripMenuItem.Text = "&Process";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Project 1: Sakordekar Mangesh";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newMenu;
        private System.Windows.Forms.ToolStripMenuItem openTestMenu;
        private System.Windows.Forms.ToolStripMenuItem openMenu;
        private System.Windows.Forms.ToolStripMenuItem saveMenu;
        private System.Windows.Forms.ToolStripMenuItem closeMenu;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ToolStripMenuItem coreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extractionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nonLinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miscToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sharpenFilter3x3CoreOption;
        private System.Windows.Forms.ToolStripMenuItem prewittFilter5x5CoreOption;
        private System.Windows.Forms.ToolStripMenuItem sobelFilter5x5ExtractionOption;
        private System.Windows.Forms.ToolStripMenuItem quarterCircleCoreOption;
        private System.Windows.Forms.ToolStripMenuItem flipRotateTranslateCoreOption;
        private System.Windows.Forms.ToolStripMenuItem gradientOverlayCoreOption;
        private System.Windows.Forms.ToolStripMenuItem makeTriangeNonLinearOption;
        private System.Windows.Forms.ToolStripMenuItem gradientStripeOverlayOption;
        private System.Windows.Forms.ToolStripMenuItem flipTopHalfLinearOption;
        private System.Windows.Forms.ToolStripMenuItem swapRedGreenExtractionOption;
        private System.Windows.Forms.ToolStripMenuItem gaussianBlurBasicOption;
        private System.Windows.Forms.ToolStripMenuItem oilPaintTextureCoreOption;
        private System.Windows.Forms.ToolStripMenuItem sineWaveLinearOption;
        private System.Windows.Forms.ToolStripMenuItem makeDiamondNonLinearOption;
        private System.Windows.Forms.ToolStripMenuItem blueColorFilterExtractionOption;
        private System.Windows.Forms.ToolStripMenuItem generateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fillWhiteMenu;
        private System.Windows.Forms.ToolStripMenuItem negativeMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem drawMenu;
        private System.Windows.Forms.ToolStripMenuItem processMenu;
        private System.Windows.Forms.ToolStripMenuItem copyMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem thresholdMenu;
        private System.Windows.Forms.ToolStripMenuItem warpNearestMenu;
        private System.Windows.Forms.ToolStripMenuItem warpBilenearMenu;
    }
}

