﻿/**
 * 
 * ************************* Project Header  ********************************
 * 
 * Project Name : CSC 524 Project 1
 * 
 * Authors : Mangesh Sakordekar, Dr. Lisa Rebenitsch
 * 
 * Description:
 * This project builds up on Tutorial 2 and adds more featues for processing images.
 * 
 * Bugs and Issues: None
 * 
 * Grading:
 * _X_ 8pt make a new\open\save image under a File Menu and add Project 1 menu
 * _X_ 2pt display the current state of the image 
 * _X_ 10pt A 3X3 sharpen filter 
 * _X_ 15pt A 5X5 Prewit or Sorbel filter 
 * _X_ 10pt Draw a 100 pixel radius quarter circle
 * _X_ 15pt A horizontal flip (no vertical), a rotation about the bottom right corner, and then a translation (x and y) afterwards 
 * _X_ 20pt A gradient screen overlay that blends with the underlying image.  
 * __ 30pt OPTIONAL for individuals, and required for teams slide show
 * _X_ 15pt (minimum) GRADUATE proposal and make a procedureal texture
 * 
 * __Gaussian Blur__[20pt] Required Blur\Sharpen\Contrast\Filter
 * 
 * __Swap Red and Green Channels__[10pt] Required Feature Extraction
 * __5x5 Sobel Filter__[10pt] Other Feature Extraction
 * __Show Only Blue Channel__[10pt] Other Feature Extraction
 * 
 * __Sine Warp__[10pt] Required Linear warp
 * __Translate Part of the image__[20pt] Other Linear warp
 * 
 * __Diamond Warp__[40pt] Required Non-linear warp
 * __Triangle Warp__[30pt] Other Non-linear warp
 * __Bilinear Interpolation__[10pt] Other Non-linear warp
 * 
 * __Gradient Stripe Overlay__[20pt] Required Composition
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace ImageProcess
{
    public partial class MainForm : Form
    {
        private String filePath = "C:\\Users\\mange\\source\\repos\\Project 1\\pictures\\";

        public enum MODE
        {
            None, Draw, Move, Threshold, WarpBilinear, WarpNearest
        }

        protected MODE mouseMode = MODE.None;
        RasterImage initImage;
        RasterImage postImage;
 
        int offset = 0;
        public MainForm()
        {
            InitializeComponent();
            SetMenuOptionEnable();
            offset = menuStrip1.Height;
            DoubleBuffered = true;
        }

        #region Drawing

        //main Paint function
        protected override void OnPaint(PaintEventArgs e)
        {
            if (initImage == null)
                return;

            Graphics g = e.Graphics;

            //color the background
            Brush b = new SolidBrush(Color.DarkGray);
            g.FillRectangle(b, e.ClipRectangle);

            if (postImage == null)
            {
                //draw only the original
                g.DrawImage(initImage.toBitmap, 0, offset);
            }
            else
            {
                //draw BOTH the original and post processed image

                g.DrawImage(initImage.toBitmap, 0, offset, initImage.Width, initImage.Height);
                g.DrawImage(postImage.toBitmap, initImage.Width + 2, offset, postImage.Width, postImage.Height);

                //
                // Draw a bar between the two images
                //
                Pen black = new Pen(Color.Black);
                black.Width = 3;

                g.DrawLine(black, new PointF(initImage.Width, offset), new PointF(initImage.Width, initImage.Height + offset));
            }
        }

        //redraw on resize
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Invalidate();
        }

        #endregion

        #region File menu
        private void newMenu_Click(object sender, EventArgs e)
        {
            initImage = new RasterImage();
            ProcessImage.FillBlack(initImage);
            SetMenuOptionEnable();
            Invalidate();
        }

        private void openTestMenu_Click(object sender, EventArgs e)
        {
            initImage = new RasterImage(new Bitmap(Properties.Resources.Stickman));
            SetMenuOptionEnable();
            Invalidate();
        }

        private void openMenu_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                initImage = new RasterImage(new Bitmap(openFileDialog.FileName));
                SetMenuOptionEnable();
                Invalidate();
            }
        }

        private void saveMenu_Click(object sender, EventArgs e)
        {
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                OnSave(saveFileDialog.FileName, saveFileDialog.FilterIndex, postImage.toBitmap);
            }
        }

        /// <summary>
        /// function to save a image. Supports, jpeg, gif, png, and bmp
        /// </summary>
        /// <param name="path">location to save</param>
        /// <param name="index">index (format type) from file dialog</param>
        /// <param name="image">image to save</param>
        /// <returns></returns>
        public bool OnSave(string path, int index, Bitmap image)
        {
            try
            {
                switch (index)
                {
                    case 1:
                        image.Save(path, ImageFormat.Jpeg);
                        break;
                    case 2:
                        image.Save(path, ImageFormat.Gif);
                        break;
                    case 3:
                        image.Save(path, ImageFormat.Png);
                        break;
                    case 4:
                        image.Save(path, ImageFormat.Bmp);
                        break;

                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error");
                return false;
            }

            return true;
        }

        private void closeMenu_Click(object sender, EventArgs e)
        {
            if(initImage != null)
                initImage.Close();
            if (postImage != null)
                postImage.Close();
            SetMenuOptionEnable();
            Invalidate();
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            Close();
        }
        

        private void SetMenuOptionEnable()
        {
            if (initImage == null)
            {
                bool on = false;
                fillWhiteMenu.Enabled = on;
                copyMenu.Enabled = on;
                negativeMenu.Enabled = on;
                thresholdMenu.Enabled = on;
                warpNearestMenu.Enabled = on;
                warpBilenearMenu.Enabled = on;
                drawMenu.Enabled = on;
            }
            else {
                bool on = true;
                fillWhiteMenu.Enabled = on;
                copyMenu.Enabled = on;
                negativeMenu.Enabled = on;
                thresholdMenu.Enabled = on;
                warpNearestMenu.Enabled = on;
                warpBilenearMenu.Enabled = on;
                drawMenu.Enabled = on;

            }

           
        }


        #endregion

        #region Generate menu
        private void copyMenu_Click(object sender, EventArgs e)
        {
            postImage = new RasterImage(initImage);
            Invalidate();
        }

        private void thresholdMenu_Click(object sender, EventArgs e)
        {
            mouseMode = MODE.Threshold;
            drawMenu.Checked = false;
        }

        private void warpNearestMenu_Click(object sender, EventArgs e)
        {
            mouseMode = MODE.WarpNearest;
            drawMenu.Checked = false;

            //make post image if needed, and clear
            if (postImage == null)
                postImage = new RasterImage(initImage.Width, initImage.Height);
            ProcessImage.FillWhite(postImage);
            Invalidate();
        }

        private void warpBilenearMenu_Click(object sender, EventArgs e)
        {
            mouseMode = MODE.WarpBilinear;
            drawMenu.Checked = false;

            //make post image if needed, and clear
            if (postImage == null)
                postImage = new RasterImage(initImage.Width, initImage.Height);
            ProcessImage.FillWhite(postImage);
            Invalidate();
        }

        #endregion

        #region Process menu

        private void fillWhiteMenu_Click(object sender, EventArgs e)
        {
            ProcessImage.FillWhite(initImage);
            Invalidate();
        }

        private void negativeMenu_Click(object sender, EventArgs e)
        {
            ProcessImage.OnFilterNegative(initImage);
            Invalidate();
        }

        private void drawMenu_Click(object sender, EventArgs e)
        {
            drawMenu.Checked = !drawMenu.Checked;
            if (drawMenu.Checked)
                mouseMode = MODE.Draw;
            else
                mouseMode = MODE.None;
            SetMenuOptionEnable();
            Invalidate();
        }


        #endregion

        #region Mouse

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e); 

            if (initImage == null)
                return;

            int width = initImage.Width;
            int height = initImage.Height;
            int x = e.X;
            int y = e.Y - offset; //Remove menu strip height from click point

            
            switch(mouseMode)
            {
                case MODE.None:
                    break;
                case MODE.Draw:
                    if (x < width && y < height)
                        initImage[x, y] = Color.Red;
                        mouseMode = MODE.Move;
                    break;
                case MODE.Move:
                    mouseMode = MODE.Draw; //if this happens, there was a glitch, restart
                    break;
                case MODE.Threshold:
                    if (postImage == null)
                        postImage = new RasterImage(initImage.Width, initImage.Height);
                    GenerateImage.FilterThreshold(initImage, postImage, x, y);
                    break;
                case MODE.WarpNearest:
                    GenerateImage.FilterWarp(initImage, postImage, x, y, true);
                    break;
                case MODE.WarpBilinear:
                    GenerateImage.FilterWarp(initImage, postImage, x, y);
                    break;
            }
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            switch (mouseMode)
            {
                case MODE.Move:
                    mouseMode = MODE.Draw; //allow a restart
                    break;
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (initImage == null)
                return;

            int width = initImage.Width;
            int height = initImage.Height;
            int x = e.X;
            int y = e.Y - offset; //Remove menu strip height from click point

            switch (mouseMode)
            {
                case MODE.None:
                    break;
                case MODE.Move:
                    if (x < width && y < height)
                    { 
                        initImage[x, y] = Color.Red;
                        Invalidate();
                    }
                    break;
                case MODE.Threshold:
                    break;
                case MODE.WarpNearest:
                    break;
                case MODE.WarpBilinear:
                    break;
            }
           
        }



        #endregion


        //265 + 10 (Bilenear Interpolation) 

        #region Core 95 pts 
        //Graduate task points had not been assigned yet, assumed 15

        /**
         * This section includes all the caller functions for the core tasks
         */

        //10 basics points
        private void sharpenFilter3x3CoreOption_Click(object sender, EventArgs e)
        {
            //10pt
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, Core.Sharpen3x3Parellel);
            Invalidate();
            //OnSave(filePath + "sharpenFilter3x3Before.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "sharpenFilter3x3After.jpg", 1, postImage.toBitmap);
        }

        private void prewittFilter5x5CoreOption_Click(object sender, EventArgs e)
        {
            //15pt
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, Core.Prewitt5x5Parellel);
            Invalidate();
            //OnSave(filePath + "prewittFilter5x5Before.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "prewittFilter5x5After.jpg", 1, postImage.toBitmap);
        }

        private void quarterCircleCoreOption_Click(object sender, EventArgs e)
        {
            //10
            postImage = new RasterImage(initImage);
            Core.QuarterCircle(initImage, postImage);
            Invalidate();
            //OnSave(filePath + "quarterCircleBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "quarterCircleAfter.jpg", 1, postImage.toBitmap);
        }

        private void gradientOverlayCoreOption_Click(object sender, EventArgs e)
        {
            //20
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, Core.GradientOverlay);
            Invalidate();
            //OnSave(filePath + "gradientOverlayBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "gradientOverlayAfter.jpg", 1, postImage.toBitmap);
        }

        private void flipRotateTranslateCoreOption_Click(object sender, EventArgs e)
        {
            //15
            DialogFlipRotateTranslate dlg = new DialogFlipRotateTranslate();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                postImage = new RasterImage(initImage.Width, initImage.Height);
                RasterImage temp = new RasterImage(initImage.Width, initImage.Height);
                initImage.parallelFilter(temp, 0, initImage.Width, 0, initImage.Height, Core.FlipHorizontal);
                Core.Rotate(temp, postImage, dlg.Angle, dlg.X, dlg.Y);
                Invalidate();
                //OnSave(filePath + "flipRotateTranslateBefore.jpg", 1, initImage.toBitmap);
                //OnSave(filePath + "flipRotateTranslateAfter.jpg", 1, postImage.toBitmap);
            }

        }

        private void oilPaintTextureCoreOption_Click(object sender, EventArgs e)
        {
            //15
            DialogBrushSize dlg = new DialogBrushSize();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                postImage = new RasterImage(initImage.Width, initImage.Height);
                Core.setBrushSize(dlg.Y);
                initImage.parallelFilter(postImage, Core.OilPaintFilter);
                Invalidate();
                //OnSave(filePath + "oilPaintTextureBefore.jpg", 1, initImage.toBitmap);
                //OnSave(filePath + "oilPaintTextureAfter.jpg", 1, postImage.toBitmap);
            }

        }
        #endregion


        #region Basic 20 pts
        /**
        * This section includes all the caller functions for the basic tasks
        */

        private void gaussianBlurBasicOption_Click(object sender, EventArgs e)
        {
            //20
            DialogGaussianSize dlg = new DialogGaussianSize();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                Basic.MakeGaussianFilter(dlg.Y, dlg.Y);
                postImage = new RasterImage(initImage.Width, initImage.Height);
                initImage.parallelFilter(postImage, Basic.GaussianBlur);
                Invalidate();
                OnSave(filePath + "gaussianBlurBefore.jpg", 1, initImage.toBitmap);
                OnSave(filePath + "gaussianBlurAfter.jpg", 1, postImage.toBitmap);
            }

        }

        #endregion


        #region Extraction 30 pts
        /**
        * This section includes all the caller functions for the extraction tasks
        */
        private void sobelFilter5x5ExtractionOption_Click(object sender, EventArgs e)
        {
            //10
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, Extraction.Sobel5x5Parellel);
            Invalidate();
            //OnSave(filePath + "sobelFilter5x5Before.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "sobelFilter5x5After.jpg", 1, postImage.toBitmap);
        }

        private void swapRedGreenExtractionOption_Click(object sender, EventArgs e)
        {
            //10
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, Extraction.SwapRedGreen);
            Invalidate();
            //OnSave(filePath + "swapRedGreenBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "swapRedGreenAfter.jpg", 1, postImage.toBitmap);
        }

        private void blueColorFilterExtractionOption_Click(object sender, EventArgs e)
        {
            //10
            postImage = new RasterImage(initImage.Width, initImage.Height);
            initImage.parallelFilter(postImage, Extraction.ColorFilter);
            Invalidate();
            //OnSave(filePath + "blueColorFilterBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "blueColorFilterAfter.jpg", 1, postImage.toBitmap);
        }
        #endregion


        #region Linear Warps 30 pts
        /**
        * This section includes all the caller functions for the linear warp tasks
        */

        private void sineWaveLinearOption_Click(object sender, EventArgs e)
        {
            //10
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, LinearWarp.SineWave);
            Invalidate();
            //OnSave(filePath + "sineWaveBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "sineWaveAfter.jpg", 1, postImage.toBitmap);
        }

        private void translateTopHalfLinearOption_Click(object sender, EventArgs e)
        {
            //20
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, LinearWarp.TranslateTopHalf);
            Invalidate();
            //OnSave(filePath + "translateTopHalfBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "translateTopHalfAfter.jpg", 1, postImage.toBitmap);

        }
        #endregion


        #region Non Linear Warps 80 pts
        /**
        * This section includes all the caller functions for the non linear warp tasks
        */
        private void makeTriangeNonLinearOption_Click(object sender, EventArgs e)
        {
            //30
            postImage = new RasterImage(initImage.Width, initImage.Height);
            initImage.parallelFilter(postImage, NonLinearWarp.MakeTriangle);
            Invalidate();
            //OnSave(filePath + "makeTriangeBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "makeTriangeAfter.jpg", 1, postImage.toBitmap);
        }

        private void makeDiamondNonLinearOption_Click(object sender, EventArgs e)
        {
            //40
            postImage = new RasterImage(initImage.Width, initImage.Height);
            initImage.parallelFilter(postImage, NonLinearWarp.MakeDiamond);
            Invalidate();
            //OnSave(filePath + "makeDiamondBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "makeDiamondAfter.jpg", 1, postImage.toBitmap);
        }
        #endregion


        #region Overlay 20 pts

        /**
        * This section includes all the caller functions for the overlay tasks
        */
        private void gradientStripeOverlayOption_Click(object sender, EventArgs e)
        {
            //20
            postImage = new RasterImage(initImage.Width, initImage.Height);

            initImage.parallelFilter(postImage, Overlay.GradientStripeOverlay);
            Invalidate();
            //OnSave(filePath + "gradientStripeOverlayBefore.jpg", 1, initImage.toBitmap);
            //OnSave(filePath + "gradientStripeOverlayAfter.jpg", 1, postImage.toBitmap);
        }

        #endregion

    }
}
