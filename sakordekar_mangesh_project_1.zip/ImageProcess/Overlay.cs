﻿/**
 * Overlay.cs
 * This file defines class Overlay wwhich contains all the functions to perform
 * overlay tasks
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageProcess
{
    internal class Overlay
    {
        /// <summary>
        /// Adds a red line across the width at the center which fades towards the 
        /// top and bottom
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color GradientStripeOverlay(int c, int r, RasterImage image)
        {
            double hheight = image.Height / 2.0;

            double grad_factor = (hheight/2.0 - Math.Abs(hheight- r))/(hheight/2.0);

            if (grad_factor < 0)
                return image[c, r];

            return ColorHelpers.ColorAdd(
                ColorHelpers.ColorMultiply(1.0-grad_factor, image[c, r]),
                ColorHelpers.ColorMultiply(grad_factor, Color.FromArgb(255, 0, 0)));
        }
    }
}
