﻿/***
 * 
 * Core.cs
 * 
 * This file holds the Core class which contains the functions for tasks
 * in the Core section.
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;

namespace ImageProcess
{
    internal class Core
    {
        private static double[,] filter3x3 = new double[3, 3]
            {
                {-1, -1, -1},
                {-1, 9, -1 },
                {-1, -1, -1},
            };

        private static double[,] filterPrewittVertical = new double[5, 5]
            {
                {-2, -1, 0, 1, 2},
                {-2, -1, 0, 1, 2},
                {-2, -1, 0, 1, 2},
                {-2, -1, 0, 1, 2},
                {-2, -1, 0, 1, 2},
            };

        private static double[,] filterPrewittHorizontal = new double[5, 5]
            {
                {2, 2, 2, 2, 2},
                {1, 1, 1, 1, 1},
                {0, 0, 0, 0, 0},
                {-1, -1, -1, -1, -1},
                {-2, -2, -2, -2, -2},
            };

        /// <summary>
        /// Sharpens the image using a 3 by 3 filter
        /// </summary>
        /// <param name="image"></param>
        /// <param name="postImage"></param>
        public static void Sharpen3x3(RasterImage image, RasterImage postImage)
        {
            int height = image.Height;
            int width = image.Width;

            double bias = 0.0;
            double factor = 1.0;
            // reset the filtered image and make the same size as the input image
            int range = 1;

            //loop over pixels
            for (int r = 0; r < height; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    Color pixel = Color.Black;
                    double tallyR = 0;
                    double tallyG = 0;
                    double tallyB = 0;

                    //loop over square around this pixel, watching boundaries
                    for (int i = -range; i <= range; i++)
                    {
                        if ((r + i) >= 0 && (r + i) < height)
                        {

                            for (int j = -range; j <= range; j++)
                            {
                                if ((c + j) >= 0 && (c + j) < width)
                                {
                                    //tally channels
                                    pixel = image[c + j, r + i];
                                    tallyR += pixel.R * filter3x3[i + range, j + range];
                                    tallyG += pixel.G * filter3x3[i + range, j + range];
                                    tallyB += pixel.B * filter3x3[i + range, j + range];
                                }
                            }
                        }
                    }

                    //average values, and set
                    pixel = Color.FromArgb(
                        ColorHelpers.ClampColorElem(tallyR * factor + bias),
                        ColorHelpers.ClampColorElem(tallyG * factor + bias),
                        ColorHelpers.ClampColorElem(tallyB * factor + bias)
                        );
                    postImage[c, r] = pixel;

                }
            }

        }

        /// <summary>
        /// Sharpens the image using a 3 by 3 filter using parallelization
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color Sharpen3x3Parellel(int c, int r, RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            double bias = 0.0;
            double factor = 1.0;
            // reset the filtered image and make the same size as the input image
            int range = 1;

            Color pixel = Color.Black;
            double tallyR = 0;
            double tallyG = 0;
            double tallyB = 0;

            //loop over square around this pixel, watching boundaries
            for (int i = -range; i <= range; i++)
            {
                if ((r + i) >= 0 && (r + i) < height)
                {

                    for (int j = -range; j <= range; j++)
                    {
                        if ((c + j) >= 0 && (c + j) < width)
                        {
                            //tally channels
                            pixel = image[c + j, r + i];
                            tallyR += pixel.R * filter3x3[i + range, j + range];
                            tallyG += pixel.G * filter3x3[i + range, j + range];
                            tallyB += pixel.B * filter3x3[i + range, j + range];
                        }
                    }
                }
            }

            //average values, and set
            return Color.FromArgb(
                ColorHelpers.ClampColorElem(tallyR * factor + bias),
                ColorHelpers.ClampColorElem(tallyG * factor + bias),
                ColorHelpers.ClampColorElem(tallyB * factor + bias)
                );
        }

        /// <summary>
        /// This function implements the Prewitt 5 by 5 filter for edge detection.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color Prewitt5x5Parellel(int c, int r, RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;

            double threshhold = 230.0;
            // reset the filtered image and make the same size as the input image
            int range = 2;

            Color pixel = Color.Black;
            double tallyH = 0;
            double tallyV = 0;
            //double tallyB = 0;

            //loop over square around this pixel, watching boundaries
            for (int i = -range; i <= range; i++)
            {
                if ((r + i) >= 0 && (r + i) < height)
                {

                    for (int j = -range; j <= range; j++)
                    {
                        if ((c + j) >= 0 && (c + j) < width)
                        {
                            //tally channels
                            pixel = image[c + j, r + i];
                            tallyH += (pixel.R + pixel.G + pixel.B) / 3.0 * filterPrewittVertical[i + range, j + range];
                            tallyV += (pixel.R + pixel.G + pixel.B) / 3.0 * filterPrewittHorizontal[i + range, j + range];
                        }
                    }
                }
            }

            //average values, and set
            if (Math.Abs(tallyH) + Math.Abs(tallyV) > threshhold)
                return ColorHelpers.ColorMultiply((Math.Abs(tallyH) + Math.Abs(tallyV)) * 0.0005, Color.White);

            return Color.Black;
        }

        /// <summary>
        /// Draws a quarter circle at the top left corner
        /// </summary>
        /// <param name="image"></param>
        /// <param name="postImage"></param>
        public static void QuarterCircle(RasterImage image, RasterImage postImage)
        {
            int height = image.Height;
            int width = image.Width;

            for (int r = 0; r < Math.Min(height, 100); r++)
            {
                int dist = (int)Math.Sqrt(10000.0 - r * r);
                for (int c = 0; c <= Math.Min(dist, width - 1); c++)
                {
                    postImage[c, r] = Color.Black;

                    if (c + 1 < width && r + 1 < height)
                        postImage[c + 1, r + 1] = ColorHelpers.ColorMultiply(0.5, image[c + 1, r + 1]);
                    if (c + 1 < width)
                        postImage[c + 1, r] = ColorHelpers.ColorMultiply(0.5, image[c + 1, r]);
                    if (r + 1 < height)
                        postImage[c, r + 1] = ColorHelpers.ColorMultiply(0.5, image[c, r + 1]);
                }
            }
        }

        /// <summary>
        /// Computes and returns the color of the pixel to
        /// add a gradient over the image.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color GradientOverlay(int c, int r, RasterImage image)
        {
            return ColorHelpers.ColorMultiply((double)c / (double)image.Width, image[c, r]);
        }

        /// <summary>
        /// Flips the image from given starting column to the given end column
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="s_x"></param>
        /// <param name="e_x"></param>
        /// <param name="s_y"></param>
        /// <param name="e_y"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color FlipHorizontal(int c, int r, int s_x, int e_x, int s_y, int e_y, RasterImage image)
        {
            if(c >= s_x && c < e_x)
                return image[e_x - (c - s_x) -1, r];
            return image[c, r];
        }

        /// <summary>
        /// Rotates and translates the image by given angle and x and y values
        /// </summary>
        /// <param name="image"></param>
        /// <param name="postImage"></param>
        /// <param name="ang"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public static void Rotate(RasterImage image, RasterImage postImage, double ang, int x, int y)
        {
            int height = image.Height;
            int width = image.Width;

            Matrix r1 = Matrix.Identity;
            r1.RotateAt(ang, width, height);
            r1.Translate(x, y);
            r1.Invert();

            //loop over target pixels
            for (int r = 0; r < height; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    System.Windows.Point v = new System.Windows.Point(c, r);
                    System.Windows.Point v2 = r1.Transform(v);

                    postImage[c, r] = NonLinearWarp.BilinearInterpolate(v2.X, v2.Y, image);
                }
            }

        }


        /*************************** Grad Task : Oil Paint Texture **************************/

        //Hold the brush size
        private static int brushSize;

        /// <summary>
        /// Sets the brush size 
        /// </summary>
        /// <param name="size"></param>
        public static void setBrushSize(int size)
        {
            brushSize = size;
        }

        /// <summary>
        /// Adds oil pait texture to the image. Parallely runs for each pixel and 
        /// computes the color by selecting the intensity which occurs the most
        /// within the brush size.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="r"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Color OilPaintFilter(int c, int r, RasterImage image)
        {
            int width = image.Width;
            int height = image.Height;

            int radius = brushSize >> 1;

            // intensity values
            //byte intensity, maxIntensity;
            int[] intensities = new int[256];
            int[] red = new int[256];
            int[] green = new int[256];
            int[] blue = new int[256];

            for (int i = -radius; i <= radius; i++)
            {
                int y = r + i;

                // skip row
                if (y < 0 || y >= height)
                    continue;

                // for each kernel column
                for (int j = -radius; j <= radius; j++)
                {
                    int x = c + j;

                    // skip column
                    if (x < 0 || x >= width)
                        continue;


                    Color p = image[x, y];

                    // grayscale value using 
                    byte intensity = (byte)(0.2125 * p.R + 0.7154 * p.G + 0.0721 * p.B);

                    intensities[intensity]++;
                    // red
                    red[intensity] += p.R;
                    // green
                    green[intensity] += p.G;
                    // blue
                    blue[intensity] += p.B;
                    
                }
            }

            // get most frequent intesity
            int maxIntensity = 0;
            int maxIntensityInd = 0;


            for (int i = 0; i < 256; i++)
            {
                if (intensities[i] > maxIntensity)
                {
                    maxIntensityInd = (byte)i;
                    maxIntensity = intensities[i];
                }
            }

            // set destination pixel
            return Color.FromArgb((red[maxIntensityInd] / intensities[maxIntensityInd]), 
                (green[maxIntensityInd] / intensities[maxIntensityInd]), 
                (blue[maxIntensityInd] / intensities[maxIntensityInd]));
        }

        /************************************************************************************/
    }
}
