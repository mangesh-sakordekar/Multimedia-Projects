﻿/***
 * Basic.cs
 * 
 * This file holds the class Basic which contains all the functions 
 * from basic section.
 * 
 */

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageProcess
{
    internal class Basic
    {
        private static double[,] filterGaussianKernel;

        /// <summary>
        /// Creates a gaussian kernel of the given width.
        /// </summary>
        /// <param name="width">desired width of the kernel</param>
        /// <param name="weight">weight to compute the intensity of the blur</param>
        public static void MakeGaussianFilter(int width, double weight)
        {
            filterGaussianKernel = new double[width, width];
            double kernelSum = 0;
            int foff = (width - 1) / 2;
            double distance = 0;
            double constant = 1.0 / (2 * Math.PI * weight * weight);

            for (int r = -foff; r <= foff; r++)
            {
                for (int c = -foff; c <= foff; c++)
                {
                    distance = ((r * r) + (c * c)) / (2 * weight * weight);
                    filterGaussianKernel[r + foff, c + foff] = constant * Math.Exp(-distance);
                    kernelSum += filterGaussianKernel[r + foff, c + foff];
                }
            }
            for (int r = 0; r < width; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    filterGaussianKernel[r, c] = filterGaussianKernel[r, c] * 1d / kernelSum;
                }
            }
        }

        /// <summary>
        /// This function uses a gaussian filter to blur the image. It is called parallelly 
        /// on each pixel of the destination image.
        /// </summary>
        /// <param name="c"> colum of the destination pixel</param>
        /// <param name="r"> row of the destination pixel</param>
        /// <param name="image"> source image</param>
        /// <returns></returns>
        public static Color GaussianBlur(int c, int r, RasterImage image)
        {
            int height = image.Height;
            int width = image.Width;


            int range = (filterGaussianKernel.GetLength(0) - 1)/2;

            Color pixel = Color.Black;
            double tallyR = 0;
            double tallyG = 0;
            double tallyB = 0;

            //loop over square around this pixel, watching boundaries
            for (int i = -range; i <= range; i++)
            {
                if ((r + i) >= 0 && (r + i) < height)
                {

                    for (int j = -range; j <= range; j++)
                    {
                        if ((c + j) >= 0 && (c + j) < width)
                        {
                            //tally channels
                            pixel = image[c + j, r + i];
                            tallyR += pixel.R * filterGaussianKernel[i + range, j + range];
                            tallyG += pixel.G * filterGaussianKernel[i + range, j + range];
                            tallyB += pixel.B * filterGaussianKernel[i + range, j + range];
                        }
                    }
                }
            }

            return Color.FromArgb(
                ColorHelpers.ClampColorElem(tallyR),
                ColorHelpers.ClampColorElem(tallyG),
                ColorHelpers.ClampColorElem(tallyB));
        }
    }
}
