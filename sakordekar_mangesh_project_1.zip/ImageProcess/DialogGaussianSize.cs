﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcess
{
    /// <summary>
    /// Dialog box to read in the kernel size for
    /// gaussian blur task
    /// </summary>
    public partial class DialogGaussianSize : Form
    {
        public int Y
        {
            get { return Convert.ToInt32(yBox.Text); }
            set { yBox.Text = value.ToString(); }
        }

        public DialogGaussianSize()
        {
            InitializeComponent();
        }
    }
}
